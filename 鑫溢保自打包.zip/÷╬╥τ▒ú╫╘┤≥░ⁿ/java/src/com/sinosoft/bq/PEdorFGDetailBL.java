package com.sinosoft.lis.bq;
import java.util.Date;

import org.apache.log4j.Logger;

import com.sinosoft.lis.db.LCContDB;
import com.sinosoft.lis.db.LCGetDB;
import com.sinosoft.lis.db.LCInsureAccClassDB;
import com.sinosoft.lis.db.LCInsureAccDB;
import com.sinosoft.lis.db.LCInsureAccTraceDB;
import com.sinosoft.lis.db.LCPolDB;
import com.sinosoft.lis.db.LJSGetDrawDB;
import com.sinosoft.lis.db.LOLoanDB;
import com.sinosoft.lis.db.LPBnfDB;
import com.sinosoft.lis.db.LPEdorAppDB;
import com.sinosoft.lis.db.LPEdorItemDB;
import com.sinosoft.lis.get.ExpireAssignBL;
import com.sinosoft.lis.pubfun.Arith;
import com.sinosoft.lis.pubfun.GlobalInput;
import com.sinosoft.lis.pubfun.MMap;
import com.sinosoft.lis.pubfun.PubFun;
import com.sinosoft.lis.pubfun.PubFun1;
import com.sinosoft.lis.pubfun.PubSubmit;
import com.sinosoft.lis.pubfun.ReportPubFun;
import com.sinosoft.lis.schema.LCContSchema;
import com.sinosoft.lis.schema.LCDutySchema;
import com.sinosoft.lis.schema.LCGetSchema;
import com.sinosoft.lis.schema.LCInsureAccClassSchema;
import com.sinosoft.lis.schema.LCInsureAccSchema;
import com.sinosoft.lis.schema.LCInsureAccTraceSchema;
import com.sinosoft.lis.schema.LCPolSchema;
import com.sinosoft.lis.schema.LJSGetDrawSchema;
import com.sinosoft.lis.schema.LJSGetEndorseSchema;
import com.sinosoft.lis.schema.LOLoanSchema;
import com.sinosoft.lis.schema.LOReturnLoanSchema;
import com.sinosoft.lis.schema.LPBnfSchema;
import com.sinosoft.lis.schema.LPEdorAppSchema;
import com.sinosoft.lis.schema.LPEdorItemSchema;
import com.sinosoft.lis.schema.LPInsureAccClassSchema;
import com.sinosoft.lis.schema.LPInsureAccSchema;
import com.sinosoft.lis.schema.LPInsureAccTraceSchema;
import com.sinosoft.lis.schema.LPLoanBalanceSchema;
import com.sinosoft.lis.schema.LPReturnLoanSchema;
import com.sinosoft.lis.vschema.LCInsureAccClassSet;
import com.sinosoft.lis.vschema.LCInsureAccSet;
import com.sinosoft.lis.vschema.LCInsureAccTraceSet;
import com.sinosoft.lis.vschema.LCPolSet;
import com.sinosoft.lis.vschema.LJSGetEndorseSet;
import com.sinosoft.lis.vschema.LOLoanBalanceSet;
import com.sinosoft.lis.vschema.LOLoanSet;
import com.sinosoft.lis.vschema.LOReturnLoanSet;
import com.sinosoft.lis.vschema.LPBnfSet;
import com.sinosoft.lis.vschema.LPEdorItemSet;
import com.sinosoft.lis.vschema.LPInsureAccClassSet;
import com.sinosoft.lis.vschema.LPInsureAccSet;
import com.sinosoft.lis.vschema.LPInsureAccTraceSet;
import com.sinosoft.lis.vschema.LPLoanBalanceSet;
import com.sinosoft.lis.vschema.LPReturnLoanSet;
import com.sinosoft.utility.CError;
import com.sinosoft.utility.CErrors;
import com.sinosoft.utility.ExeSQL;
import com.sinosoft.utility.Reflections;
import com.sinosoft.utility.SSRS;
import com.sinosoft.utility.TransferData;
import com.sinosoft.utility.VData;

/**
 * Title: Webҵ��ϵͳ
 * Description: ������ȡ
 * Copyright: Copyright (c) 2017
 * Company: Sinosoft
 * @version 1.0
 */

public class PEdorFGDetailBL implements EdorDetail {
private static Logger logger = Logger.getLogger(PEdorFGDetailBL.class);
	/** �������࣬ÿ����Ҫ�����������ж����ø��� */
	public CErrors mErrors = new CErrors();
	/** �����洫�����ݵ����� */
	private VData mInputData;
	private MMap mMap = new MMap();
	/** �����洫�����ݵ����� */
	private VData mResult = new VData();
	private ExeSQL mExeSQL = new ExeSQL();

	/** ���ݲ����ַ��� */
	private String mOperate;

	private double mCanGetMoney = 0.00; // ���������
	private double mActGetMoney = 0.00; // ����ʵ����

	/** ȫ������ */
	private LPEdorItemSchema mLPEdorItemSchema = new LPEdorItemSchema();
	//modify by yangjilu 20180614 ��ITREQUEST-2849���ͻ���������
	private String mEdorAppDate = "";
	//end by yangjilu
	private GlobalInput mGlobalInput = new GlobalInput();
	private LPBnfSet mLPBnfSet = new LPBnfSet();
	private LCContSchema mLCContSchema = new LCContSchema();
	private String mSerialNo = "";

	private String mCurrentDate = PubFun.getCurrentDate();
	private String mCurrentTime = PubFun.getCurrentTime();

	private double mLoanCorpus = 0.00;
	private double mLoanInterest = 0.00;
	boolean misLoanFlag = true;
	public PEdorFGDetailBL() {
	}

	public VData getResult() {
		return mResult;
	}

	/**
	 * �����ύ�Ĺ�������
	 * 
	 * @param: cInputData ���������
	 * @param: cOperate ���ݲ����ַ���
	 * @return:
	 */
	public boolean submitData(VData cInputData, String cOperate) {
		logger.debug("==========PEdorFGDetailBL==========��ʼ===========");

		mInputData = (VData) cInputData.clone();
		mOperate = cOperate;
		mResult.clear();

		if (!getInputData()) {
			return false;
		}
		if (!checkData()) {
			return false;
		}
		if ("EDORITEM|UPDATE".equals(mOperate)){
			if(!dealBnfData()) {
				return false;
			}
		} else if("EdorSave".equals(mOperate)){
			if (!dealEdorSave()) {
				return false;
			}
		}
		mResult.clear();
		mResult.add(mMap);

		logger.debug("==========PEdorFGDetailBL==========����===========");

		return true;
	}

	/**
	 * ���ڱ��ս���ȡ��ϸ����
	 *
	 */
	private boolean dealEdorSave() {

		//��ѯ�����Ƿ�����ֹ
		LCPolDB tLCPolDB = new LCPolDB();
		tLCPolDB.setContNo(mLPEdorItemSchema.getContNo());
		tLCPolDB.setAppFlag("1");
		LCPolSet tLCPolSet = new LCPolSet();
		tLCPolSet = tLCPolDB.query();
		if(tLCPolSet.size() == 0){
			logger.debug("����["+ mLPEdorItemSchema.getContNo() +"]��������ֹ��");
			tLCPolDB.setAppFlag("4");
			tLCPolSet = tLCPolDB.query();
			if(tLCPolSet.size() == 0){
				mErrors.addOneError(new CError("����["+ mLPEdorItemSchema.getContNo() +"]��ѯ������Ϣʧ�ܣ�"));
				return false;
			}
		} else{
			//����δ��ֹ����б�����ֹ����
			VData tContInvaliVData = new VData();
			TransferData tTransfer = new TransferData();
			tTransfer.setNameAndValue("ManageCom", mGlobalInput.ManageCom);
			tTransfer.setNameAndValue("LCPolSet", tLCPolSet);
			tContInvaliVData.add(tTransfer);
			ContInvaliBLMultThreads tContInvaliBL = new ContInvaliBLMultThreads();
			logger.debug("Start ContInvaliBL ====" + mLPEdorItemSchema.getContNo());
			if (!tContInvaliBL.submitData(tContInvaliVData, "SingleTerminate")) {
				logger.debug(tContInvaliBL.mErrors.getError(0).errorMessage);
				mErrors.addOneError(new CError(tContInvaliBL.mErrors.getFirstError()));
				return false;
			}
			logger.debug("End ContInvaliBL ====" + mLPEdorItemSchema.getContNo());
		}
		//��ѯ�Ƿ����ɷ����ڽ𣨷��ı�C�ĳ��������޲����ǣ�
		String tSQL = "select count(*) from lcget where livegettype='0' and getintv='0' and getendstate='0' and getdutycode not in('P70203') and getdutycode in (select a.getdutycode from lmdutyget a where a.gettype1='0' and a.type='0' and a.getdutyname like '%����%') and contno='"+mLPEdorItemSchema.getContNo()+"'";
		logger.debug(tSQL);
		int temp =Integer.parseInt(mExeSQL.getOneValue(tSQL));
		//��û���ɷ���������ڽ��ɷ�
		if(temp>0){
			//��ѯ�ñ��������������ε�����
			LCPolSet tEFLCPolSet = new LCPolSet();
			String tExpireSql = "";
			String tExpireFLag = "";
			for (int i = 1; i <= tLCPolSet.size(); i++) {
				tExpireSql = "select 1 from lcget where livegettype='0' and getintv='0' and getendstate='0' and getdutycode not in('P70203') and polno='"+ tLCPolSet.get(i).getPolNo() + "'";
				tExpireFLag = mExeSQL.getOneValue(tExpireSql);
				if (tExpireFLag != null && !"".equals(tExpireFLag) && Integer.parseInt(tExpireFLag) == 1) {
					tEFLCPolSet.add(tLCPolSet.get(i));
				}
			}
			mSerialNo = PubFun1.CreateMaxNo("SERIALNO", PubFun.getNoLimit(mGlobalInput.ManageCom));
			if (tEFLCPolSet.size() == 0){
				mErrors.addOneError(new CError("����["+ mLPEdorItemSchema.getContNo() +"]�޿��ɷ����ڱ��ս�����֣�"));
				return false;
			} else if (tEFLCPolSet.size() > 0){
				logger.debug("����["+tEFLCPolSet.get(1).getContNo()+"]���ɷ����ڽ����ָ���:"+tEFLCPolSet.size());
				TransferData tTransferData = new TransferData();
				tTransferData.setNameAndValue("LCPolSet", tEFLCPolSet);
				tTransferData.setNameAndValue("SerialNo", mSerialNo);
				VData tVData = new VData();
				tVData.add(tTransferData);
				tVData.add(mGlobalInput);
				//����ExpireAssignBL���������ɷ�
				ExpireAssignBL tExpireAssignBL = new ExpireAssignBL();
				if (!tExpireAssignBL.submitData(tVData, "edorItem")){
					mErrors.addOneError(new CError(tExpireAssignBL.mErrors.getFirstError()));
					return false;
				}
			}
		}
		LCContDB tLCContDB = new LCContDB();
		tLCContDB.setContNo(mLPEdorItemSchema.getContNo());
		if(!tLCContDB.getInfo()){
			mErrors.addOneError(new CError("����["+mLPEdorItemSchema.getContNo()+"]��Ϣ��ѯʧ�ܣ�"));
			return false;
		}
		mLCContSchema.setSchema(tLCContDB.getSchema());

		//���ɱ�ȫ��¼��Ӧ����¼
		if (!CreateEdorData(mLPEdorItemSchema.getContNo())){
			mErrors.addOneError(new CError("����["+mLPEdorItemSchema.getContNo()+"]���ɱ�ȫ��ر�ʧ�ܣ�"));
			return false;
		}
		
		return true;
	}

	/**
	 * �������˻���ͬʱ��������Ӧ����¼
	 * @param cContno ������
	 */
	private boolean CreateEdorData(String cContno) {
		LCInsureAccClassDB tLCInsureAccClassDB = new LCInsureAccClassDB();
		LCInsureAccDB tLCInsureAccDB = new LCInsureAccDB();
		LCInsureAccSet tLCInsureAccSet = new LCInsureAccSet();
		tLCInsureAccDB.setContNo(cContno);
		tLCInsureAccDB.setInsuAccNo("000031");
		tLCInsureAccSet = tLCInsureAccDB.query();
		if(tLCInsureAccSet.size()==0){
			mErrors.addOneError(new CError("���ڽ�δ�ɷ���"));
			return false;
		}
		double tGetMoney = 0.00;
		double tExpireMoney = 0.00;
		
		LPInsureAccClassSet tLpClassSet = new LPInsureAccClassSet();
		LPInsureAccSet tLpAccSet = new LPInsureAccSet();
		Reflections tReflections = new Reflections();

		String tLCClassSQL = "";
		for (int i = 1; i <= tLCInsureAccSet.size(); i++) {
			tExpireMoney = tLCInsureAccSet.get(i).getInsuAccBala();
			LCPolDB tLCPolDB = new LCPolDB();
			tLCPolDB.setContNo(cContno);
			tLCPolDB.setPolNo(tLCInsureAccSet.get(i).getPolNo());
			LCPolSchema tLCPolSchema = new LCPolSchema();
			if(!tLCPolDB.getInfo()){
				mErrors.addOneError(new CError("����["+ cContno +"]��ѯ������Ϣʧ�ܣ�"));
				return false;
			}
			tLCPolSchema.setSchema(tLCPolDB.getSchema());
			//����Ӧ������
			LCInsureAccTraceDB tLCInsureAccTrace1DB = new LCInsureAccTraceDB();
			tLCInsureAccTrace1DB.setContNo(tLCInsureAccSet.get(i).getContNo());
			tLCInsureAccTrace1DB.setPolNo(tLCInsureAccSet.get(i).getPolNo());
			tLCInsureAccTrace1DB.setInsuAccNo("000031");
			LCInsureAccTraceSet tLCInsureAccTraceSet = new LCInsureAccTraceSet();
			tLCInsureAccTraceSet = tLCInsureAccTrace1DB.query();
			for (int j = 1; j <= tLCInsureAccTraceSet.size(); j++){
				if(!createLJSGetEndorse(tLCInsureAccTraceSet.get(j).getMoney(), BqCode.Get_GetDraw, tLCInsureAccTraceSet.get(j).getMoneyType(),tLCPolSchema)){
					mErrors.addOneError(new CError("����["+tLCInsureAccSet.get(i).getPolNo()+"]����Ӧ������ʧ�ܣ�"));
					return false;
				}
			}
			tGetMoney += tLCInsureAccSet.get(i).getInsuAccBala();

			
			/*
			 * ��������峥:�˴�ֻ�Ա��������������ε����ֽ��н���峥���н��δ�峥�����������ε����ֵı�������ڴ�������������
			 */
			//���ڱ�������δ����������Ѻ����״̬��־��������Ϊtrue
			misLoanFlag = checkIsLoan(cContno,tLCInsureAccSet.get(i).getPolNo());
			double tLoanAddInterest = 0.00;
			LCInsureAccTraceDB tLCInsureAccTraceDB = new LCInsureAccTraceDB();
			tLCInsureAccTraceDB.setContNo(tLCInsureAccSet.get(i).getContNo());
			tLCInsureAccTraceDB.setPolNo(tLCInsureAccSet.get(i).getPolNo());
			tLCInsureAccTraceDB.setInsuAccNo("000031");
			tLCInsureAccTraceDB.setMoneyType("EF");
			LCInsureAccTraceSchema tLCInsureAccTraceSchema = tLCInsureAccTraceDB.query().get(1);
			if(!misLoanFlag){
				logger.debug("====�����峥");
				mLoanCorpus = 0.00;
				mLoanInterest = 0.00;
				tLoanAddInterest = getLoanAddInterest(mLCContSchema.getContNo(), tLCPolSchema.getPolNo(), tLCPolSchema.getEndDate());
				if(tLoanAddInterest == -1){
					mErrors.addOneError(new CError("����[" + tLCPolSchema.getPolNo() + "]�����峥ʧ��!"));
					return false;
				}
				if((mLoanCorpus + mLoanInterest) > 0.00){
					//��������峥���Ѽ�¼
					if (!createLJSGetEndorse(mLoanCorpus, BqCode.Pay_LoanCorpus, "HK",tLCPolSchema)){
						return false;
					}
					if (!createLJSGetEndorse(mLoanInterest,BqCode.Pay_LoanCorpusInterest, "LX", tLCPolSchema)) {
						return false;
					}
					LPInsureAccTraceSchema tHKLPInsureAccTrace = createLPInsureAccTraceSchema(tLCInsureAccTraceSchema, "HK", -mLoanCorpus);
					LPInsureAccTraceSchema tLXLPInsureAccTrace = createLPInsureAccTraceSchema(tLCInsureAccTraceSchema, "LX", -mLoanInterest);
					mMap.put(tHKLPInsureAccTrace, "INSERT");
					mMap.put(tLXLPInsureAccTrace, "INSERT");
				}
			}
			if(tLoanAddInterest > 0.00){
				tExpireMoney = tExpireMoney - tLoanAddInterest;
				tGetMoney = tGetMoney - tLoanAddInterest;
			}

//			LPInsureAccTraceSchema tEFLPInsureAccTrace = createLPInsureAccTraceSchema(tLCInsureAccTraceSchema, "EF", -tExpireMoney);
			//chenyixuan ���ڶ��� ֮ǰ�����������
			LPInsureAccTraceSchema tEFLPInsureAccTrace = createLPInsureAccTraceSchema(tLCInsureAccTraceSchema, "LQ", -tExpireMoney);

			//p����¼
			LPInsureAccSchema tLpAccSchema = new LPInsureAccSchema();
			tReflections.transFields(tLpAccSchema,tLCInsureAccSet.get(i));
			tLpAccSchema.setEdorNo(mLPEdorItemSchema.getEdorNo());
			tLpAccSchema.setEdorType(mLPEdorItemSchema.getEdorType());
			tLpAccSchema.setLastAccBala(tLCInsureAccSet.get(i).getInsuAccBala());
			tLpAccSchema.setInsuAccBala(0.00);
			tLpAccSchema.setBalaDate(mCurrentDate);
			tLpAccSchema.setMakeDate(mCurrentDate);
			tLpAccSchema.setMakeTime(mCurrentTime);
			tLpAccSchema.setModifyDate(mCurrentDate);
			tLpAccSchema.setModifyTime(mCurrentTime);
			tLpAccSet.add(tLpAccSchema);
			tLCClassSQL = "select * from LCInsureAccClass where contno='"+cContno+"' and insuaccno='000031' and polno='"+tLCInsureAccSet.get(i).getPolNo()+"'";
			LCInsureAccClassSchema tLCInsureAccClassSchema = new LCInsureAccClassSchema();
			tLCInsureAccClassSchema = tLCInsureAccClassDB.executeQuery(tLCClassSQL).get(1);
			LPInsureAccClassSchema tLpClassSchema = new LPInsureAccClassSchema();
			tReflections.transFields(tLpClassSchema,tLCInsureAccClassSchema);
			tLpClassSchema.setEdorNo(mLPEdorItemSchema.getEdorNo());
			tLpClassSchema.setEdorType(mLPEdorItemSchema.getEdorType());
			tLpClassSchema.setLastAccBala(tLCInsureAccClassSchema.getInsuAccBala());
			tLpClassSchema.setInsuAccBala(0.00);
			tLpClassSchema.setBalaDate(mCurrentDate);
			tLpClassSchema.setMakeDate(mCurrentDate);
			tLpClassSchema.setMakeTime(mCurrentTime);
			tLpClassSchema.setModifyDate(mCurrentDate);
			tLpClassSchema.setModifyTime(mCurrentTime);
			tLpClassSet.add(tLpClassSchema);
			mMap.put(tLpClassSchema, "DELETE&INSERT");
			mMap.put(tLpAccSet, "DELETE&INSERT");
			//add by liujian  20180816
			mMap.put("delete from lpinsureacctrace where edorno='"+mLPEdorItemSchema.getEdorNo()+"' and polno='"+tLCInsureAccSet.get(i).getPolNo()+"' and edortype='FG'", "DELETE");
			//end by liujian 
			mMap.put(tEFLPInsureAccTrace, "DELETE&INSERT");
		}
		
		//���������ˣ�������Լ���⣬���ڱ��ս��������Ϊ�������˱��ˣ�
		String tInsuredNoSql = "select insuredno,name,sex,birthday,idtype,idno from lcinsured where relationtomaininsured='00' and sequenceno='1' and contno='"+cContno+"'";
		SSRS tSSRS = new SSRS();
		tSSRS = mExeSQL.execSQL(tInsuredNoSql);
		if(tSSRS.getMaxRow() == 0){
			mErrors.addOneError(new CError("���ұ���["+cContno+"]��������Ϣʧ�ܣ�"));
			return false;
		}
		String tInsuredNo = tSSRS.GetText(1, 1);
		String tName = tSSRS.GetText(1, 2);
		String tSex = tSSRS.GetText(1, 3);
		String tBirthday = tSSRS.GetText(1, 4);
		String tIDType = tSSRS.GetText(1, 5);
		String tIDNo = tSSRS.GetText(1, 6);
		LPBnfSchema tLPBnfSchema = new LPBnfSchema();
		//EDORNO, EDORTYPE, POLNO, INSUREDNO, BNFTYPE, BNFNO, BNFGRADE
		tLPBnfSchema.setEdorNo(mLPEdorItemSchema.getEdorNo());
		tLPBnfSchema.setEdorType("FG");
		tLPBnfSchema.setPolNo("000000");
		tLPBnfSchema.setContNo(cContno);
		tLPBnfSchema.setInsuredNo(tInsuredNo);
		tLPBnfSchema.setCustomerNo(tInsuredNo);
		tLPBnfSchema.setName(tName);
		tLPBnfSchema.setSex(tSex);
		tLPBnfSchema.setBirthday(tBirthday);
		tLPBnfSchema.setIDType(tIDType);
		tLPBnfSchema.setIDNo(tIDNo);
		tLPBnfSchema.setBnfType("0");
		tLPBnfSchema.setBnfNo(1);
		tLPBnfSchema.setBnfGrade("1");
		tLPBnfSchema.setBnfLot(1.00);
		tLPBnfSchema.setRemark("4");//�Զ�ת��
		//String tInsuredAgeSql = "select trunc(months_between('"+mLPEdorItemSchema.getEdorAppDate()+"' ,'"+tBirthday+"' ) / 12) from dual";
		//modify by yangjilu 20180614 ��ITREQUEST-2849������������ʹ�ÿͻ��������ڼ���
		String tInsuredAgeSql = "select trunc(months_between('"+mEdorAppDate+"' ,'"+tBirthday+"' ) / 12) from dual";
		//end by yangjilu
		int InsuredAge = Integer.parseInt(mExeSQL.getOneValue(tInsuredAgeSql));
		if (InsuredAge>=18){
			tLPBnfSchema.setRelationToInsured("00");
		} else{
			tLPBnfSchema.setRelationToInsured("");
		}
		tLPBnfSchema.setMakeDate(mCurrentDate);
		tLPBnfSchema.setMakeTime(mCurrentTime);
		tLPBnfSchema.setModifyDate(mCurrentDate);
		tLPBnfSchema.setModifyTime(mCurrentTime);
		tLPBnfSchema.setOperator(mGlobalInput.Operator);
		mMap.put(tLPBnfSchema, "DELETE&INSERT");
		
		//�޸ı�ȫ��
		mLPEdorItemSchema.setGetMoney(-tGetMoney);
		mLPEdorItemSchema.setCurrency("01");
		mMap.put(mLPEdorItemSchema, "UPDATE");
		return true;
	}
	
	/**
	 * ���ɹ켣����������
	 * @return
	 */
	private LPInsureAccTraceSchema createLPInsureAccTraceSchema(LCInsureAccTraceSchema cLCInsureAccTraceSchema,
			String cMoneyType, double cMoney) {
		// TODO Auto-generated method stub
		LPInsureAccTraceSchema tLPInsureAccTrace = new LPInsureAccTraceSchema();
		Reflections tReflections = new Reflections();
		tReflections.transFields(tLPInsureAccTrace,cLCInsureAccTraceSchema);
		tLPInsureAccTrace.setEdorNo(mLPEdorItemSchema.getEdorNo());
		tLPInsureAccTrace.setEdorType(mLPEdorItemSchema.getEdorType());
		String tSerialNo = PubFun1.CreateMaxNo("SERIALNO", PubFun.getNoLimit(mGlobalInput.ManageCom));
		tLPInsureAccTrace.setSerialNo(tSerialNo);		
		tLPInsureAccTrace.setMoney(cMoney);
		tLPInsureAccTrace.setBusyType("BQ");
		tLPInsureAccTrace.setEdorType("FG");
		String finType = BqCalBL.getFinType_HL_SC("SC", tLPInsureAccTrace.getInsuAccNo(), cMoneyType);
		tLPInsureAccTrace.setMoneyType(finType);
		tLPInsureAccTrace.setValueDate(mCurrentDate);
		tLPInsureAccTrace.setMakeDate(mCurrentDate);
		tLPInsureAccTrace.setMakeTime(mCurrentTime);
		tLPInsureAccTrace.setModifyDate(mCurrentDate);
		tLPInsureAccTrace.setModifyTime(mCurrentTime);
		tLPInsureAccTrace.setAccAlterNo(mLPEdorItemSchema.getEdorNo());
		tLPInsureAccTrace.setAccAlterType("3");
		return tLPInsureAccTrace;
	}

	/**
	 * �޸������
	 * @return
	 */
	private boolean dealBnfData() {
		if(this.mLPBnfSet==null||this.mLPBnfSet.size()<=0)
		{
			mErrors.addOneError(new CError("����ʵ����ȡ��������!"));
			return false;
		}
		LPEdorAppDB tLPEdorAppDB = new LPEdorAppDB();
		LPEdorAppSchema tLPEdorAppSchema = new LPEdorAppSchema();
		tLPEdorAppDB.setEdorAcceptNo(mLPEdorItemSchema.getEdorAcceptNo());
		if(!tLPEdorAppDB.getInfo()){
			return false;
		}
		tLPEdorAppSchema.setSchema(tLPEdorAppDB.getSchema());

		for(int j = 1;j <= this.mLPBnfSet.size();j++)
		{
			LPBnfDB _tLPBnfDB = new LPBnfDB();
			_tLPBnfDB.setEdorNo(this.mLPEdorItemSchema.getEdorNo());
			_tLPBnfDB.setEdorType(this.mLPEdorItemSchema.getEdorType());
			_tLPBnfDB.setPolNo("000000");
			//_tLPBnfDB.setInsuredNo(this.mLPEdorItemSchema.getInsuredNo());
			_tLPBnfDB.setBnfType("0");
			_tLPBnfDB.setBnfNo(j);
			_tLPBnfDB.setBnfGrade("1");
			LPBnfSet _tLPBnfSet = _tLPBnfDB.query();
			LPBnfSchema tLPBnfSchema = new LPBnfSchema();
			
			if (_tLPBnfSet.size() == 0){
				tLPBnfSchema.setEdorNo(this.mLPEdorItemSchema.getEdorNo());
				tLPBnfSchema.setEdorType("FG");
				tLPBnfSchema.setPolNo("000000");
				tLPBnfSchema.setContNo(this.mLPEdorItemSchema.getContNo());
				tLPBnfSchema.setInsuredNo(this.mLPEdorItemSchema.getInsuredNo());
				tLPBnfSchema.setCustomerNo(this.mLPEdorItemSchema.getInsuredNo());
				tLPBnfSchema.setName(mLPBnfSet.get(j).getName());
				tLPBnfSchema.setSex(mLPBnfSet.get(j).getSex());
				tLPBnfSchema.setBirthday(mLPBnfSet.get(j).getBirthday());
				tLPBnfSchema.setIDType(mLPBnfSet.get(j).getIDType());
				tLPBnfSchema.setIDNo(mLPBnfSet.get(j).getIDNo());
				tLPBnfSchema.setBnfType("0");
				tLPBnfSchema.setBnfNo(j);
				tLPBnfSchema.setBnfGrade("1");
				tLPBnfSchema.setBnfLot(mLPBnfSet.get(j).getBnfLot());
				tLPBnfSchema.setRemark(mLPBnfSet.get(j).getRemark());//�Զ�ת��
				tLPBnfSchema.setRelationToInsured(mLPBnfSet.get(j).getRelationToInsured());
				tLPBnfSchema.setBankCode(mLPBnfSet.get(j).getBankCode());
		    	tLPBnfSchema.setBankAccNo(mLPBnfSet.get(j).getBankAccNo());
		    	tLPBnfSchema.setAccName(mLPBnfSet.get(j).getAccName());
		    	if(!"00".equals(mLPBnfSet.get(j).getRelationToInsured())){
			    	tLPBnfSchema.setIDType(mLPBnfSet.get(j).getIDType());
			    	tLPBnfSchema.setIDNo(mLPBnfSet.get(j).getIDNo());
			    	tLPBnfSchema.setIDExpDate(mLPBnfSet.get(j).getIDExpDate());
	    		}
				tLPBnfSchema.setMakeDate(mCurrentDate);
				tLPBnfSchema.setMakeTime(mCurrentTime);
				tLPBnfSchema.setModifyDate(mCurrentDate);
				tLPBnfSchema.setModifyTime(mCurrentTime);
				tLPBnfSchema.setOperator(mGlobalInput.Operator);
				mMap.put(tLPBnfSchema, "DELETE&INSERT");
			} else{
				tLPBnfSchema = _tLPBnfSet.get(1);
				tLPBnfSchema.setName(mLPBnfSet.get(j).getName());
		    	tLPBnfSchema.setSex(mLPBnfSet.get(j).getSex());
		    	tLPBnfSchema.setBirthday(mLPBnfSet.get(j).getBirthday());
		    	tLPBnfSchema.setIDType(mLPBnfSet.get(j).getIDType());
		    	tLPBnfSchema.setIDNo(mLPBnfSet.get(j).getIDNo());
		    	tLPBnfSchema.setRelationToInsured(mLPBnfSet.get(j).getRelationToInsured());
		    	tLPBnfSchema.setBnfLot(mLPBnfSet.get(j).getBnfLot());
		    	tLPBnfSchema.setRemark(mLPBnfSet.get(j).getRemark());
		    	tLPBnfSchema.setBankCode(mLPBnfSet.get(j).getBankCode());
		    	tLPBnfSchema.setBankAccNo(mLPBnfSet.get(j).getBankAccNo());
		    	tLPBnfSchema.setAccName(mLPBnfSet.get(j).getAccName());
		    	if (!"00".equals(mLPBnfSet.get(j).getRelationToInsured())){
			    	tLPBnfSchema.setIDType(mLPBnfSet.get(j).getIDType());
			    	tLPBnfSchema.setIDNo(mLPBnfSet.get(j).getIDNo());
			    	tLPBnfSchema.setIDExpDate(mLPBnfSet.get(j).getIDExpDate());
	    		}
				tLPBnfSchema.setBnfNo(j);
				tLPBnfSchema.setModifyDate(mCurrentDate);
				tLPBnfSchema.setModifyTime(mCurrentTime);
				mMap.put(tLPBnfSchema, "UPDATE");
			}
			if(1==tLPBnfSchema.getBnfNo()){
				tLPEdorAppSchema.setBankAccNo(tLPBnfSchema.getBankAccNo());
				tLPEdorAppSchema.setBankCode(tLPBnfSchema.getBankCode());
				tLPEdorAppSchema.setAccName(tLPBnfSchema.getAccName());
				tLPEdorAppSchema.setPayForm(tLPBnfSchema.getRemark());
				tLPEdorAppSchema.setGetForm(tLPBnfSchema.getRemark());
				//tLPEdorAppSchema.setPersonIDType(tLPBnfSchema.getIDType()); //�ո�������֤������ add by yangruosen
				mMap.put(tLPEdorAppSchema, "UPDATE");
			}
		}
		
		return true;
	}
	
	/**
	 * �������Ĳ��˷Ѽ�¼
	 * @param dMoneyValue ���˷ѽ��
	 * @param sSubFeeOperationType ��ҵ������
	 * @param sBQFeeType
	 * @param pLCDutySchema
	 * @return
	 */
	private boolean createLJSGetEndorse(double dMoneyValue,String sSubFeeOperationType, String sBQFeeType, LCPolSchema cLCPolSchema) {
		// TODO Auto-generated method stub
		LCGetDB mLCGetDB = new LCGetDB();
		String tLcGetSql = "select * from lcget where livegettype='0' and getintv='0' and getdutycode not in('P70203') and polno='"+ cLCPolSchema.getPolNo() + "'";
		LCGetSchema tLCGetSchema = mLCGetDB.executeQuery(tLcGetSql).get(1);
		if (tLCGetSchema == null) {
			mErrors.addOneError(new CError("����[" + cLCPolSchema.getPolNo()+ "]�������ѯʧ��!"));
			return false;
		}
		LJSGetEndorseSchema tLJSGetEndorseSchema = new LJSGetEndorseSchema();
		tLJSGetEndorseSchema = this.initLJSGetEndorse(mLPEdorItemSchema, cLCPolSchema, tLCGetSchema, sSubFeeOperationType, sBQFeeType, Arith.round(dMoneyValue, 2));
		if ("HK".equals(sBQFeeType) || "LX".equals(sBQFeeType)) {
			tLJSGetEndorseSchema.setGetFlag("0");
		}
		mMap.put(tLJSGetEndorseSchema, "DELETE&INSERT");

		return true;
	}
	
	/**
	 * �������δ�峥������Ϣ�����Դ�������峥����
	 * 
	 * @return double 
	 */
	private double getLoanAddInterest(String pContNo, String cPolNo, String pCountDate) {
		double dLoanAddInterest = 0.0;
		LPReturnLoanSet tLPReturnLoanSet = new LPReturnLoanSet();
		double tSumMoney = 0.0;
		double tSumInterest =0.0;
		// ׼���ӽ��ҵ����л�ȡ�������
		LOLoanDB tLOLoanDB = new LOLoanDB();
		tLOLoanDB.setContNo(pContNo);
		tLOLoanDB.setPolNo(cPolNo);
		tLOLoanDB.setLoanType("0"); // ��������
		tLOLoanDB.setPayOffFlag("0"); // δ����
		LOLoanSet tLOLoanSet = new LOLoanSet();
		tLOLoanSet = tLOLoanDB.query();
		if (tLOLoanSet != null && tLOLoanSet.size() > 0) {
			for (int i = 1; i <= tLOLoanSet.size(); i++) {
				double tInterest =0.0;
				//�������
				tSumMoney += format(tLOLoanSet.get(i).getLeaveMoney());
				
				BqPolBalBL tBqPolBalBL = new BqPolBalBL();
				if (tBqPolBalBL.calLoanInterest(tLOLoanSet.get(i),pContNo, pCountDate)){
					tInterest = format(tBqPolBalBL.getCalResult());
					logger.debug(tInterest);
					//����������Ϣ
					
					LPReturnLoanSchema tLPReturnLoanSchema =dealLoanReturn(tLOLoanSet.get(i),tInterest);
					if(tLPReturnLoanSchema==null){
						mErrors.addOneError(new CError("����[" + cPolNo + "]����δ�峥������Ϣ����ʧ��!"));
						return -1;
					}
					tLPReturnLoanSet.add(tLPReturnLoanSchema);
				
				} else{
					mErrors.addOneError(new CError("����[" + cPolNo + "]����δ�峥������Ϣ����ʧ��!"));
					return -1;
				}
				tSumInterest+=tInterest;
			}

			//�����½���Ϣ��
			LOLoanBalanceSet tLOLoanBalanceSet = new LOLoanBalanceSet();
			LPLoanBalanceSet tLPLoanBalanceSet = new LPLoanBalanceSet();
			Reflections tReflections = new Reflections();
			VData tInputData = new VData();
			tInputData.add(pCountDate);  //����ȡ������ֹ����
			tInputData.add(mLCContSchema);
			tInputData.add(tLOLoanSet);
			tInputData.add(mGlobalInput);
			LoanBalanceBL tLoanBalanceBL = new LoanBalanceBL();
			if (!tLoanBalanceBL.submitData(tInputData, "LoanBala")){
				logger.debug("����������"+ cPolNo+ " �����½���Ϣʧ�ܡ�");
				return -1;
			} else{
				VData rResult =tLoanBalanceBL.getResult();
				tLOLoanBalanceSet=(LOLoanBalanceSet)rResult.getObjectByObjectName("LOLoanBalanceSet", 0);
				if (tLOLoanBalanceSet == null){
					logger.debug("����������"+ cPolNo +" �����½���Ϣʧ�ܡ�");
					return -1;
				}else{
					for (int j = 1; j <= tLOLoanBalanceSet.size(); j++) 
					{
						LPLoanBalanceSchema tLPLoanBalanceSchema = new LPLoanBalanceSchema();
						tReflections.transFields(tLPLoanBalanceSchema,tLOLoanBalanceSet.get(j));
						tLPLoanBalanceSchema.setEdorNo(mLPEdorItemSchema.getEdorNo());
						tLPLoanBalanceSchema.setEdorType(mLPEdorItemSchema.getEdorType());
						tLPLoanBalanceSet.add(tLPLoanBalanceSchema);
					}
				}
			}
			mLoanCorpus =tSumMoney;
			mLoanInterest = tSumInterest;

			mMap.put(tLPReturnLoanSet, "DELETE&INSERT");
			mMap.put(tLPLoanBalanceSet, "DELETE&INSERT");

			dLoanAddInterest = format(mLoanCorpus + mLoanInterest);
		} 
		
		return dLoanAddInterest;
	}
	
	/**
	 * ���Ӵ�����Ϣ���������ɷ������ڻ���״̬�Ĵ���
	 * @param cLOLoanSchema
	 * @param cIntrest
	 * @return
	 */
	private LPReturnLoanSchema dealLoanReturn(LOLoanSchema cLOLoanSchema, double cIntrest) 
	{
		// ��֯����
		LPReturnLoanSchema tLPReturnLoanSchema = new LPReturnLoanSchema();
		tLPReturnLoanSchema.setContNo(cLOLoanSchema.getContNo());
		tLPReturnLoanSchema.setPolNo(cLOLoanSchema.getPolNo());
		tLPReturnLoanSchema.setEdorType("FG");
		tLPReturnLoanSchema.setSerialNo(cLOLoanSchema.getSerialNo()); 
		tLPReturnLoanSchema.setActuGetNo(cLOLoanSchema.getActuGetNo()); 
		tLPReturnLoanSchema.setLoanType(cLOLoanSchema.getLoanType()); 
		tLPReturnLoanSchema.setOrderNo(cLOLoanSchema.getOrderNo()); 
		tLPReturnLoanSchema.setLoanDate(cLOLoanSchema.getLoanDate()); 
		
		tLPReturnLoanSchema.setSumMoney(cLOLoanSchema.getSumMoney()); 
		tLPReturnLoanSchema.setInputFlag(cLOLoanSchema.getInputFlag()); 
		tLPReturnLoanSchema.setInterestType(cLOLoanSchema.getInterestType()); 
		tLPReturnLoanSchema.setInterestRate(cLOLoanSchema.getInterestRate()); 
		tLPReturnLoanSchema.setInterestMode(cLOLoanSchema.getInterestMode());
		tLPReturnLoanSchema.setRateCalType(cLOLoanSchema.getRateCalType()); 
		tLPReturnLoanSchema.setRateCalCode(cLOLoanSchema.getRateCalCode()); 
		tLPReturnLoanSchema.setSpecifyRate(cLOLoanSchema.getSpecifyRate());
		tLPReturnLoanSchema.setCurrency(cLOLoanSchema.getCurrency());
		tLPReturnLoanSchema.setLeaveMoney(0); // ���
		
		// ����,�ı�����״̬
		tLPReturnLoanSchema.setPayOffFlag("1");
		tLPReturnLoanSchema.setPayOffDate(mLPEdorItemSchema.getEdorValiDate());
		tLPReturnLoanSchema.setOperator("SYS");
		tLPReturnLoanSchema.setMakeDate(mCurrentDate);
		tLPReturnLoanSchema.setMakeTime(mCurrentTime);
		tLPReturnLoanSchema.setModifyDate(mCurrentDate);
		tLPReturnLoanSchema.setModifyTime(mCurrentTime);
		tLPReturnLoanSchema.setEdorNo(mLPEdorItemSchema.getEdorNo());
		tLPReturnLoanSchema.setLoanNo(cLOLoanSchema.getEdorNo()); // ԭ�����ţ����洫��,�ؼ��ֶΣ���Ӧ�Ǵλ�����ڿ��Զ�λ������Գ���
		tLPReturnLoanSchema.setReturnMoney(cLOLoanSchema.getLeaveMoney()); // ���뻹��ı���
		tLPReturnLoanSchema.setReturnInterest(cIntrest); //��Ż������Ϣ
		return tLPReturnLoanSchema;
	}
	
	/**
	 * �������뱣����λС��
	 * @return boolean
	 */
	private double format(double dInput) {
		double dReturn = Arith.round(dInput, 2);
		return dReturn;
	}
	
	/**
	 * �����������еõ����ж���
	 * 
	 * @return
	 */
	private boolean getInputData() {
		try {
			mLPEdorItemSchema = (LPEdorItemSchema) mInputData
					.getObjectByObjectName("LPEdorItemSchema", 0);
			mGlobalInput = (GlobalInput) mInputData.getObjectByObjectName(
					"GlobalInput", 0);
			mLPBnfSet = (LPBnfSet)mInputData.getObjectByObjectName("LPBnfSet", 0);
		} catch (Exception e) {
			mErrors.addOneError("��������ʧ�ܡ�");
			return false;
		}
		return true;
	}

	/**
	 * ����У��
	 * 
	 * @return boolean
	 */
	private boolean checkData() {

		LPEdorItemDB tLPEdorItemDB = new LPEdorItemDB();
		tLPEdorItemDB.setEdorAcceptNo(mLPEdorItemSchema.getEdorAcceptNo());
		tLPEdorItemDB.setEdorNo(mLPEdorItemSchema.getEdorNo());
		tLPEdorItemDB.setEdorType(mLPEdorItemSchema.getEdorType());
		tLPEdorItemDB.setContNo(mLPEdorItemSchema.getContNo());
		if((mLPEdorItemSchema.getEdorAcceptNo() == null || mLPEdorItemSchema
				.getEdorAcceptNo().equals(""))
				&& (mLPEdorItemSchema.getEdorNo() == null || mLPEdorItemSchema
						.getEdorNo().equals("")))
		{
			mErrors.addOneError(new CError("ȱ�ٲ�ѯ������"));
			return false;
		}
		//modify by yangjilu 20180614 ��ITREQUEST-2849���ͻ���������
		String edorappdate_sql = "select edorappdate from lpedorapp where EdorAcceptNo='"+mLPEdorItemSchema.getEdorAcceptNo()+"'";
		ExeSQL tExeSQL = new ExeSQL();
		mEdorAppDate = tExeSQL.getOneValue(edorappdate_sql).substring(0, 10);
		//end by yangjilu
		LPEdorItemSet tLPEdorItemSet = tLPEdorItemDB.query();
		if (tLPEdorItemDB.mErrors.needDealError()) {
			mErrors.addOneError("��ѯ������Ŀ��Ϣʧ�ܣ�");
			return false;
		}
		mLPEdorItemSchema.setSchema(tLPEdorItemSet.get(1));
		return true;
	}

	/**
	 * ���ɽ��˷��Ӽ�¼
	 *  @param aLPEdorItemSchema
	 * @param aLCPolSchema
	 * @param aLCDutySchema
	 * @param aOperationType
	 * @param aFeeType
	 * @param aGetMoney ���˷ѽ��
	 * @return boolean
	 */	
	public LJSGetEndorseSchema initLJSGetEndorse(LPEdorItemSchema aLPEdorItemSchema, LCPolSchema aLCPolSchema,
			LCGetSchema aLCGetSchema, String aOperationType, String aFeeType, double aGetMoney) {
		try {
			LJSGetEndorseSchema rLJSGetEndorseSchema = new LJSGetEndorseSchema();
			rLJSGetEndorseSchema.setGetMoney(ReportPubFun.functionJD(aGetMoney, "0.00"));
			rLJSGetEndorseSchema.setEndorsementNo(mLPEdorItemSchema.getEdorNo());
			rLJSGetEndorseSchema.setSerialNo(mSerialNo);
			rLJSGetEndorseSchema.setGetNoticeNo(mLPEdorItemSchema.getEdorNo());
			rLJSGetEndorseSchema.setDutyCode(aLCGetSchema.getDutyCode());
			rLJSGetEndorseSchema.setGetDate(mLPEdorItemSchema.getEdorValiDate());
			if("YFHL".equals(aFeeType)){
				rLJSGetEndorseSchema.setFeeFinaType("LJTF");
			} else if ("YFLG".equals(aFeeType)){//add by lml 
				rLJSGetEndorseSchema.setFeeFinaType("YF");
			}else{
				rLJSGetEndorseSchema.setFeeFinaType(aFeeType);
			}
			rLJSGetEndorseSchema.setFeeOperationType(mLPEdorItemSchema.getEdorType());
			rLJSGetEndorseSchema.setAppntNo(aLCPolSchema.getAppntNo());
			//rLJSGetEndorseSchema.setGrpName("");
			rLJSGetEndorseSchema.setGrpContNo(aLCPolSchema.getGrpContNo());
			rLJSGetEndorseSchema.setGrpPolNo(aLCPolSchema.getGrpPolNo());
			rLJSGetEndorseSchema.setContNo(aLCPolSchema.getContNo());
			rLJSGetEndorseSchema.setPolNo(aLCPolSchema.getPolNo());
			rLJSGetEndorseSchema.setPolType("1");
			rLJSGetEndorseSchema.setInsuredNo(aLCPolSchema.getInsuredNo());
			rLJSGetEndorseSchema.setAgentCode(aLCPolSchema.getAgentCode());
			rLJSGetEndorseSchema.setAgentCom(aLCPolSchema.getAgentCom());
			rLJSGetEndorseSchema.setAgentGroup(aLCPolSchema.getAgentGroup());
			rLJSGetEndorseSchema.setAgentType(aLCPolSchema.getAgentType());
			rLJSGetEndorseSchema.setRiskCode(aLCPolSchema.getRiskCode());
			rLJSGetEndorseSchema.setKindCode(aLCPolSchema.getKindCode());
			rLJSGetEndorseSchema.setRiskVersion(aLCPolSchema.getRiskVersion());
	
			rLJSGetEndorseSchema.setOtherNo(mLPEdorItemSchema.getEdorNo());
			rLJSGetEndorseSchema.setOtherNoType("3");
			rLJSGetEndorseSchema.setPayPlanCode("000000");
			rLJSGetEndorseSchema.setGetFlag("1");
			rLJSGetEndorseSchema.setSubFeeOperationType(aOperationType);
			rLJSGetEndorseSchema.setMakeDate(mCurrentDate);
			rLJSGetEndorseSchema.setMakeTime(mCurrentTime);
			rLJSGetEndorseSchema.setModifyDate(mCurrentDate);
			rLJSGetEndorseSchema.setModifyTime(mCurrentTime);
			rLJSGetEndorseSchema.setOperator(mGlobalInput.Operator);
			rLJSGetEndorseSchema.setManageCom(aLCPolSchema.getManageCom());
			rLJSGetEndorseSchema.setCurrency(aLCPolSchema.getCurrency());
			
			return rLJSGetEndorseSchema;		

		} catch (Exception ex) {
			mErrors.addOneError(new CError("�������Ĳ��˷���Ϣ�쳣��"));
			return null;
		}

	}
	
	/**
	 * �жϱ����Ƿ���ڱ�������δ����������Ѻ����״̬
	 * @param contNo
	 * @return
	 */
	private boolean checkIsLoan(String contNo,String polNo) {
		// TODO Auto-generated method stub
		boolean isLoan = true;
		String tSQL = "select 1 from lccontstate where statetype ='Loan' and enddate is null and state = '1' and contno = '"+contNo+"'";
		if(mExeSQL.execSQL(tSQL).getMaxRow()> 0){
			LOLoanDB tLOLoanDB = new LOLoanDB();
			tLOLoanDB.setContNo(contNo);
			tLOLoanDB.setPolNo(polNo);
			tLOLoanDB.setLoanType("0"); // ��������
			tLOLoanDB.setPayOffFlag("0"); // δ����
			LOLoanSet tLOLoanSet = new LOLoanSet();
			tLOLoanSet = tLOLoanDB.query();
			if(tLOLoanSet.size()>0){
				isLoan = false;
			}
		}
		return isLoan;
	}

	
	public CErrors getErrors() {
		return mErrors;
	}
}
